package app.ba.service;
public interface CustomerService {
}
