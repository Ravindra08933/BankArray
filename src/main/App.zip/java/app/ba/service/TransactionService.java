package app.ba.service;
public interface TransactionService {
}
